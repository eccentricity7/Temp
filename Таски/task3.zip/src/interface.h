#pragma once

void printMenu();
void printStudent(student* student);