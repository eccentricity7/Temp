#pragma once
#include "student.h"

student* getOldest(int recordNumber, student* allStudents);